package com.example.ui.export

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonPink
import com.example.ui.theme.SurfaceVariantDark
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportScreen(
    bitmap: Bitmap,
    onNavigateBack: () -> Unit,
    onNavigateHome: () -> Unit
) {
    val context = LocalContext.current

    var activeFormat by remember { mutableStateOf("JPEG") }
    var jpegQuality by remember { mutableStateOf(95f) }
    var scaleMultiplier by remember { mutableStateOf("1x") }
    var stripMetadata by remember { mutableStateOf(true) }

    var isExporting by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableStateOf(0f) }
    var showSuccessDialog by remember { mutableStateOf(false) }

    // Simulated saving task inside hand-made animation frame ticks
    fun startExportProcess() {
        isExporting = true
        exportProgress = 0f

        val handler = Handler(Looper.getMainLooper())
        var currentTick = 0
        val runnable = object : Runnable {
            override fun run() {
                currentTick += 12
                exportProgress = (currentTick / 100f).coerceIn(0f, 1f)
                if (currentTick < 100) {
                    handler.postDelayed(this, 180)
                } else {
                    isExporting = false
                    showSuccessDialog = true
                }
            }
        }
        handler.postDelayed(runnable, 150)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Export Masterpiece", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Navigate Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // 1. Live layout thumbnail card representing completed design work
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.9f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF0C0C0C))
                    .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = bitmap,
                    contentDescription = "Completed Masterpiece Preview",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                )
            }

            // 2. Format options: JPEG, PNG, WEBP selection list
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Output Format", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimaryDark)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val formats = listOf("JPEG", "PNG", "WEBP")
                    formats.forEach { option ->
                        val isSelected = activeFormat == option
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) ElectricPurple else SurfaceVariantDark)
                                .border(
                                    width = if (isSelected) 1.5.dp else 0.dp,
                                    color = if (isSelected) Color.White else Color.Transparent,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { activeFormat = option }
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                option,
                                color = if (isSelected) Color.White else Color.Gray,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            // Quality slider for JPEG files
            if (activeFormat == "JPEG") {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("JPEG Compression Quality", fontSize = 12.sp, color = TextSecondaryDark)
                        Text("${jpegQuality.toInt()}%", fontSize = 13.sp, color = NeonPink, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = jpegQuality,
                        onValueChange = { jpegQuality = it },
                        valueRange = 10f..100f,
                        colors = SliderDefaults.colors(
                            thumbColor = ElectricPurple,
                            activeTrackColor = ElectricPurple,
                            inactiveTrackColor = Color.DarkGray
                        )
                    )
                }
            }

            // 3. Resolution scaling selector: Original 1x, Studio 2x, Infinite 4x
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Export Resolution Quality", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimaryDark)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val scales = listOf("1x" to "Original", "2x" to "Creative HD", "4x" to "Pro Ultra HD")
                    scales.forEach { pair ->
                        val isSelected = scaleMultiplier == pair.first
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) ElectricPurple else SurfaceVariantDark)
                                .clickable { scaleMultiplier = pair.first }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(pair.first, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(pair.second, color = if (isSelected) Color.White.copy(alpha = 0.8f) else Color.Gray, fontSize = 9.sp)
                            }
                        }
                    }
                }
            }

            // 4. Privacy stripped EXIF toggle option
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(SurfaceVariantDark)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Strip Personal EXIF Data", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Remove lens parameters and GPS location tags", fontSize = 10.sp, color = TextSecondaryDark)
                }
                Switch(
                    checked = stripMetadata,
                    onCheckedChange = { stripMetadata = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = ElectricPurple
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 5. Finalize Mega Export Button
            Button(
                onClick = { startExportProcess() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .testTag("export_save_button"),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                shape = RoundedCornerShape(16.dp),
                enabled = !isExporting
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Save, contentDescription = "Save Masterpiece")
                    Text("Save to Dev Gallery", fontSize = 16.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }

    // Export progress dialog loader overlay
    if (isExporting) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.85f)),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 40.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CircularProgressIndicator(
                    progress = { exportProgress },
                    color = ElectricPurple,
                    strokeWidth = 6.dp,
                    trackColor = Color.DarkGray,
                    modifier = Modifier.size(72.dp)
                )
                Spacer(modifier = Modifier.height(24.dp))
                val percentage = (exportProgress * 100).toInt()
                Text(
                    text = "Compiling vector layers: $percentage%",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { exportProgress },
                    color = ElectricPurple,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(CircleShape)
                )
            }
        }
    }

    // Success Confirmation Modal Dialog and Share launcher
    if (showSuccessDialog) {
        AlertDialog(
            onDismissRequest = { showSuccessDialog = false },
            icon = { Icon(Icons.Default.CheckCircle, "Success Tick", tint = Color.Green, modifier = Modifier.size(54.dp)) },
            title = {
                Text(
                    "Art Saved Successfully!",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    color = Color.White
                )
            },
            text = {
                Text(
                    "Your photo design is compiled and saved inside the device local storage. Share it with your friends below!",
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    color = TextPrimaryDark
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSuccessDialog = false
                        // Launch native share action simulation
                        try {
                            val tempFile = File(context.cacheDir, "shared_masterpiece.jpg")
                            val out = FileOutputStream(tempFile)
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out)
                            out.flush()
                            out.close()

                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "image/jpeg"
                                putExtra(Intent.EXTRA_SUBJECT, "Creative Design Masterpiece")
                                putExtra(Intent.EXTRA_STREAM, Uri.fromFile(tempFile))
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share Masterpiece"))
                        } catch (e: Exception) {
                            // Empty simulator catch
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.Share, "Share icon", modifier = Modifier.size(16.dp))
                        Text("Share Now")
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showSuccessDialog = false
                        onNavigateHome()
                    }
                ) {
                    Text("Go to Home Dashboard", color = Color.LightGray)
                }
            },
            containerColor = Color(0xFF141414)
        )
    }
}
