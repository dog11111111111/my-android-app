package com.example.ui.editor

import android.graphics.Bitmap
import android.graphics.RectF
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.models.*
import com.example.engine.ImageProcessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

sealed class EditorUiState {
    object Idle : EditorUiState()
    object Loading : EditorUiState()
    data class Success(val bitmap: Bitmap) : EditorUiState()
    data class Error(val message: String) : EditorUiState()
}

class EditorViewModel : ViewModel() {

    // UI state
    private val _uiState = MutableStateFlow<EditorUiState>(EditorUiState.Idle)
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    // Original loaded image
    private val _originalBitmap = MutableStateFlow<Bitmap?>(null)
    val originalBitmap: StateFlow<Bitmap?> = _originalBitmap.asStateFlow()

    // Edited image combining Adjustments + Filters + Beauty
    private val _processedBitmap = MutableStateFlow<Bitmap?>(null)
    val processedBitmap: StateFlow<Bitmap?> = _processedBitmap.asStateFlow()

    // Active Category Tool
    private val _currentTool = MutableStateFlow<String>("Adjust")
    val currentTool: StateFlow<String> = _currentTool.asStateFlow()

    // --- ADJUST STATE ---
    val brightness = MutableStateFlow(0f)
    val contrast = MutableStateFlow(0f)
    val saturation = MutableStateFlow(0f)
    val warmth = MutableStateFlow(0f)
    val vignette = MutableStateFlow(0f)
    val sharpness = MutableStateFlow(0f)

    // --- FILTERS STATE ---
    val selectedFilter = MutableStateFlow("None")
    val filterIntensity = MutableStateFlow(100f) // 0 to 100

    // --- BEAUTY STATE ---
    val skinSmooth = MutableStateFlow(0f)
    val skinBrighten = MutableStateFlow(0f)

    // --- BRUSH STATE ---
    private val _brushSettings = MutableStateFlow(BrushSettings())
    val brushSettings: StateFlow<BrushSettings> = _brushSettings.asStateFlow()

    private val _strokes = MutableStateFlow<List<DrawingStroke>>(emptyList())
    val strokes: StateFlow<List<DrawingStroke>> = _strokes.asStateFlow()

    private val _activeStrokePoints = MutableStateFlow<List<Offset>>(emptyList())
    val activeStrokePoints: StateFlow<List<Offset>> = _activeStrokePoints.asStateFlow()

    // --- TEXT STATE ---
    private val _textOverlays = MutableStateFlow<List<TextOverlay>>(emptyList())
    val textOverlays: StateFlow<List<TextOverlay>> = _textOverlays.asStateFlow()

    private val _selectedTextId = MutableStateFlow<UUID?>(null)
    val selectedTextId: StateFlow<UUID?> = _selectedTextId.asStateFlow()

    // --- STICKERS STATE ---
    private val _stickerOverlays = MutableStateFlow<List<StickerOverlay>>(emptyList())
    val stickerOverlays: StateFlow<List<StickerOverlay>> = _stickerOverlays.asStateFlow()

    private val _selectedStickerId = MutableStateFlow<UUID?>(null)
    val selectedStickerId: StateFlow<UUID?> = _selectedStickerId.asStateFlow()

    // --- LIQUIFY ENGINE MESH ---
    val meshWidth = 20
    val meshHeight = 20
    val originalMeshPoints = MutableStateFlow<FloatArray?>(null)
    val meshPoints = MutableStateFlow<FloatArray?>(null)
    val isLiquifyActive = MutableStateFlow(false)
    val liquifyBrushType = MutableStateFlow("push") // push, expand, contract, twirl
    val liquifyBrushRadius = MutableStateFlow(150f)
    val liquifyBrushStrength = MutableStateFlow(0.5f)

    // --- CROP STATE ---
    val rotationDegrees = MutableStateFlow(0f)
    val flipHorizontal = MutableStateFlow(false)
    val flipVertical = MutableStateFlow(false)
    val currentCropPercent = MutableStateFlow(RectF(0f, 0f, 1f, 1f))

    // --- OVERLAYS & DOUBLE EXPOSURE ---
    val overlayIntensity = MutableStateFlow(0f)
    val overlayType = MutableStateFlow("None") // None, Light Leak, Film Grain, Bokeh

    // --- UNDO / REDO HISTORY ENGINE ---
    private val undoStack = mutableListOf<HistoryItem>()
    private val redoStack = mutableListOf<HistoryItem>()

    data class HistoryItem(
        val brightness: Float,
        val contrast: Float,
        val saturation: Float,
        val warmth: Float,
        val vignette: Float,
        val sharpness: Float,
        val filter: String,
        val skinSmooth: Float,
        val skinBrighten: Float,
        val strokes: List<DrawingStroke>,
        val textOverlays: List<TextOverlay>,
        val stickerOverlays: List<StickerOverlay>,
        val rotationDegrees: Float,
        val flipHorizontal: Boolean,
        val flipVertical: Boolean,
        val cropPercent: RectF,
        val overlayIntensity: Float,
        val overlayType: String,
        val meshPoints: FloatArray?
    )

    private fun resetAllSettings() {
        _currentTool.value = "Adjust"
        brightness.value = 0f
        contrast.value = 0f
        saturation.value = 0f
        warmth.value = 0f
        vignette.value = 0f
        sharpness.value = 0f
        selectedFilter.value = "None"
        filterIntensity.value = 100f
        skinSmooth.value = 0f
        skinBrighten.value = 0f
        _brushSettings.value = BrushSettings()
        _strokes.value = emptyList()
        _activeStrokePoints.value = emptyList()
        _textOverlays.value = emptyList()
        _selectedTextId.value = null
        _stickerOverlays.value = emptyList()
        _selectedStickerId.value = null
        isLiquifyActive.value = false
        liquifyBrushType.value = "push"
        liquifyBrushRadius.value = 150f
        liquifyBrushStrength.value = 0.5f
        rotationDegrees.value = 0f
        flipHorizontal.value = false
        flipVertical.value = false
        currentCropPercent.value = RectF(0f, 0f, 1f, 1f)
        overlayIntensity.value = 0f
        overlayType.value = "None"
        undoStack.clear()
        redoStack.clear()
    }

    fun initializeWithBitmap(bitmap: Bitmap) {
        resetAllSettings()
        viewModelScope.launch {
            _uiState.value = EditorUiState.Loading
            // Scale and manage bitmap size to 2048 maximum to maintain stellar rendering performance
            val scaledBitmap = scaleBitmapIfNeeded(bitmap)
            _originalBitmap.value = scaledBitmap
            _processedBitmap.value = scaledBitmap
            
            // Create liquify mesh points
            val initialMesh = ImageProcessor.createInitialMesh(
                scaledBitmap.width.toFloat(),
                scaledBitmap.height.toFloat(),
                meshWidth,
                meshHeight
            )
            originalMeshPoints.value = initialMesh
            meshPoints.value = initialMesh.clone()

            saveToHistory()
            _uiState.value = EditorUiState.Success(scaledBitmap)
            triggerReconstruction()
        }
    }

    private fun scaleBitmapIfNeeded(bitmap: Bitmap): Bitmap {
        val maxDim = 2048
        val w = bitmap.width
        val h = bitmap.height
        if (w <= maxDim && h <= maxDim) return bitmap
        val ratio = w.toFloat() / h.toFloat()
        val targetW: Int
        val targetH: Int
        if (w > h) {
            targetW = maxDim
            targetH = (maxDim / ratio).toInt()
        } else {
            targetH = maxDim
            targetW = (maxDim * ratio).toInt()
        }
        return Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
    }

    fun selectTool(toolName: String) {
        _currentTool.value = toolName
        if (toolName.lowercase() == "liquify") {
            isLiquifyActive.value = true
        } else {
            isLiquifyActive.value = false
        }
    }

    // --- ADJUSTMENT SETTERS WITH DYNAMIC PREVIEW --
    fun updateBrightness(value: Float) {
        brightness.value = value
        triggerReconstruction()
    }

    fun updateContrast(value: Float) {
        contrast.value = value
        triggerReconstruction()
    }

    fun updateSaturation(value: Float) {
        saturation.value = value
        triggerReconstruction()
    }

    fun updateWarmth(value: Float) {
        warmth.value = value
        triggerReconstruction()
    }

    fun updateVignette(value: Float) {
        vignette.value = value
        triggerReconstruction()
    }

    fun updateSharpness(value: Float) {
        sharpness.value = value
        triggerReconstruction()
    }

    fun selectFilter(filterName: String) {
        selectedFilter.value = filterName
        triggerReconstruction()
    }

    fun updateSkinBeauty(smooth: Float, brighten: Float) {
        skinSmooth.value = smooth
        skinBrighten.value = brighten
        triggerReconstruction()
    }

    fun updateOverlay(type: String, intensity: Float) {
        overlayType.value = type
        overlayIntensity.value = intensity
        triggerReconstruction()
    }

    // --- BRUSH STROKE ACTIONS ---
    fun updateBrushSettings(settings: BrushSettings) {
        _brushSettings.value = settings
    }

    fun startBrushStroke(point: Offset) {
        _activeStrokePoints.value = listOf(point)
    }

    fun appendBrushStrokePoint(point: Offset) {
        val list = _activeStrokePoints.value.toMutableList()
        list.add(point)
        _activeStrokePoints.value = list
    }

    fun endBrushStroke() {
        val points = _activeStrokePoints.value
        if (points.isNotEmpty()) {
            val stroke = DrawingStroke(
                points = points,
                settings = _brushSettings.value
            )
            val updated = _strokes.value.toMutableList().apply { add(stroke) }
            _strokes.value = updated
            _activeStrokePoints.value = emptyList()
            saveToHistory()
        }
    }

    fun clearAllStrokes() {
        _strokes.value = emptyList()
        saveToHistory()
    }

    // --- TEXT LAYERS ACTIONS ---
    fun addTextOverlay(text: String, color: Color = Color.White, font: String = "Syne") {
        val textOverlay = TextOverlay(text = text, color = color, fontName = font)
        _textOverlays.value = _textOverlays.value.toMutableList().apply { add(textOverlay) }
        _selectedTextId.value = textOverlay.id
        saveToHistory()
    }

    fun updateTextOverlay(overlay: TextOverlay) {
        val list = _textOverlays.value.toMutableList()
        val idx = list.indexOfFirst { it.id == overlay.id }
        if (idx != -1) {
            list[idx] = overlay
            _textOverlays.value = list
        }
    }

    fun deleteSelectedText() {
        _selectedTextId.value?.let { id ->
            _textOverlays.value = _textOverlays.value.filter { it.id != id }
            _selectedTextId.value = null
            saveToHistory()
        }
    }

    fun selectText(id: UUID?) {
        _selectedTextId.value = id
    }

    // --- STICKERS OPERATIONS ---
    fun addSticker(stickerName: String) {
        val sticker = StickerOverlay(stickerName = stickerName)
        _stickerOverlays.value = _stickerOverlays.value.toMutableList().apply { add(sticker) }
        _selectedStickerId.value = sticker.id
        saveToHistory()
    }

    fun updateSticker(sticker: StickerOverlay) {
        val list = _stickerOverlays.value.toMutableList()
        val idx = list.indexOfFirst { it.id == sticker.id }
        if (idx != -1) {
            list[idx] = sticker
            _stickerOverlays.value = list
        }
    }

    fun deleteSelectedSticker() {
        _selectedStickerId.value?.let { id ->
            _stickerOverlays.value = _stickerOverlays.value.filter { it.id != id }
            _selectedStickerId.value = null
            saveToHistory()
        }
    }

    fun selectSticker(id: UUID?) {
        _selectedStickerId.value = id
    }

    // --- CROP & TRANSFORM OPERATIONS ---
    fun applyCropPreset(ratioW: Float, ratioH: Float) {
        if (ratioW == 0f || ratioH == 0f) {
            currentCropPercent.value = RectF(0f, 0f, 1f, 1f)
        } else {
            // center crop region
            val currentRatio = ratioW / ratioH
            if (currentRatio > 1f) {
                currentCropPercent.value = RectF(0f, 0.15f, 1f, 0.85f)
            } else {
                currentCropPercent.value = RectF(0.15f, 0f, 0.85f, 1f)
            }
        }
        triggerReconstruction()
    }

    fun rotate90() {
        rotationDegrees.value = (rotationDegrees.value + 90f) % 360f
        triggerReconstruction()
    }

    fun toggleFlipHorizontal() {
        flipHorizontal.value = !flipHorizontal.value
        triggerReconstruction()
    }

    fun toggleFlipVertical() {
        flipVertical.value = !flipVertical.value
        triggerReconstruction()
    }

    // --- LIQUIFY REAL TIME WARPING ACTIONS ---
    fun applyLiquifyWarpAt(touchX: Float, touchY: Float, dragX: Float, dragY: Float) {
        val currentMesh = meshPoints.value ?: return
        val updated = ImageProcessor.warpMesh(
            mesh = currentMesh,
            touchX = touchX,
            touchY = touchY,
            dragX = dragX,
            dragY = dragY,
            radius = liquifyBrushRadius.value,
            strength = liquifyBrushStrength.value,
            warpType = liquifyBrushType.value
        )
        meshPoints.value = updated
        triggerReconstruction()
    }

    fun resetLiquifyMesh() {
        val initial = originalMeshPoints.value ?: return
        meshPoints.value = initial.clone()
        triggerReconstruction()
        saveToHistory()
    }

    // --- HISTORY HANDLING (UNDO/REDO ACTION STACKS) ---
    fun saveToHistory() {
        val item = HistoryItem(
            brightness = brightness.value,
            contrast = contrast.value,
            saturation = saturation.value,
            warmth = warmth.value,
            vignette = vignette.value,
            sharpness = sharpness.value,
            filter = selectedFilter.value,
            skinSmooth = skinSmooth.value,
            skinBrighten = skinBrighten.value,
            strokes = _strokes.value,
            textOverlays = _textOverlays.value,
            stickerOverlays = _stickerOverlays.value,
            rotationDegrees = rotationDegrees.value,
            flipHorizontal = flipHorizontal.value,
            flipVertical = flipVertical.value,
            cropPercent = currentCropPercent.value,
            overlayIntensity = overlayIntensity.value,
            overlayType = overlayType.value,
            meshPoints = meshPoints.value?.clone()
        )
        // Keep within 50 steps
        if (undoStack.size >= 50) {
            undoStack.removeAt(0)
        }
        undoStack.add(item)
        redoStack.clear()
    }

    fun undo() {
        if (undoStack.size > 1) { // keep first initialized state
            val current = undoStack.removeAt(undoStack.size - 1)
            redoStack.add(current)

            val previous = undoStack.last()
            restoreFromHistoryItem(previous)
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            val item = redoStack.removeAt(redoStack.size - 1)
            undoStack.add(item)
            restoreFromHistoryItem(item)
        }
    }

    private fun restoreFromHistoryItem(item: HistoryItem) {
        brightness.value = item.brightness
        contrast.value = item.contrast
        saturation.value = item.saturation
        warmth.value = item.warmth
        vignette.value = item.vignette
        sharpness.value = item.sharpness
        selectedFilter.value = item.filter
        skinSmooth.value = item.skinSmooth
        skinBrighten.value = item.skinBrighten
        _strokes.value = item.strokes
        _textOverlays.value = item.textOverlays
        _stickerOverlays.value = item.stickerOverlays
        rotationDegrees.value = item.rotationDegrees
        flipHorizontal.value = item.flipHorizontal
        flipVertical.value = item.flipVertical
        currentCropPercent.value = item.cropPercent
        overlayIntensity.value = item.overlayIntensity
        overlayType.value = item.overlayType
        item.meshPoints?.let {
            meshPoints.value = it.clone()
        }
        triggerReconstruction()
    }

    // --- RECONSTRUCTION & PIPELINE RENDER ENGINE ---
    private fun triggerReconstruction() {
        val original = _originalBitmap.value ?: return
        viewModelScope.launch {
            _uiState.value = EditorUiState.Loading
            val rendered = withContext(Dispatchers.Default) {
                // 1. Core adjustments (Filters + Adjust sliders)
                var result = ImageProcessor.applyAdjustments(
                    base = original,
                    brightness = brightness.value,
                    contrast = contrast.value,
                    saturation = saturation.value,
                    warmth = warmth.value,
                    vignette = vignette.value,
                    sharpness = sharpness.value
                )

                if (selectedFilter.value != "None" && selectedFilter.value.isNotEmpty()) {
                    result = ImageProcessor.applyFilterPreset(result, selectedFilter.value)
                }

                // 2. Crop, Flip & Rotate Transformations
                if (rotationDegrees.value != 0f || flipHorizontal.value || flipVertical.value || currentCropPercent.value != RectF(0f, 0f, 1f, 1f)) {
                    result = ImageProcessor.transformBitmap(
                        base = result,
                        rotationDegrees = rotationDegrees.value,
                        cropRectPercent = currentCropPercent.value,
                        flipHorizontal = flipHorizontal.value,
                        flipVertical = flipVertical.value
                    )
                }

                // 3. Beauty modifications
                if (skinSmooth.value > 0f || skinBrighten.value > 0f) {
                    result = ImageProcessor.applyBeauty(
                        base = result,
                        skinSmoothStrength = skinSmooth.value,
                        skinBrightenStrength = skinBrighten.value
                    )
                }

                // 4. Warp deformation (Liquify Mesh overlay)
                val activeMesh = meshPoints.value
                if (activeMesh != null && isLiquifyActive.value) {
                    // Mesh points must be resized to post-crop size, or we simulate liquify deformation
                    result = ImageProcessor.applyLiquifyWarp(
                        base = result,
                        meshPoints = activeMesh,
                        meshWidth = meshWidth,
                        meshHeight = meshHeight
                    )
                }

                result
            }
            _processedBitmap.value = rendered
            _uiState.value = EditorUiState.Success(rendered)
        }
    }
}
