package com.example.ui.home

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonPink
import com.example.ui.theme.TextSecondaryDark

data class RecentEdit(val id: Int, val title: String, val imageUrl: String)
data class QuickTool(val title: String, val icon: ImageVector, val action: String, val badge: String = "")
data class TemplateItem(val id: Int, val title: String, val imageUrl: String, val likes: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onStartEditing: () -> Unit,
    onSelectQuickTool: (String) -> Unit
) {
    val recentEdits = remember {
        listOf(
            RecentEdit(1, "Neon Portrait", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300"),
            RecentEdit(2, "Sunset Glitch", "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300"),
            RecentEdit(3, "Cyber Gothic", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300"),
            RecentEdit(4, "Retro Film", "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300")
        )
    }

    val quickTools = remember {
        listOf(
            QuickTool("BG Remover", Icons.Default.AutoFixHigh, "bg_remove", "AI"),
            QuickTool("Collage", Icons.Default.GridView, "collage"),
            QuickTool("Templates", Icons.Default.PhotoLibrary, "templates"),
            QuickTool("Beauty", Icons.Default.Face, "beauty", "Free"),
            QuickTool("Filters", Icons.Default.FilterBAndW, "filters"),
            QuickTool("Draw", Icons.Default.Brush, "draw")
        )
    }

    val trendingTemplates = remember {
        listOf(
            TemplateItem(1, "Retro Film Strip", "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=500", "24.5k"),
            TemplateItem(2, "Cyberpunk Lights", "https://images.unsplash.com/photo-1511447333015-45b65e60f6d5?w=500", "18.2k"),
            TemplateItem(3, "Magical Bloom", "https://images.unsplash.com/photo-1526047932273-341f2a7631f9?w=500", "31.0k"),
            TemplateItem(4, "Grungy Collage", "https://images.unsplash.com/photo-1549490349-8643362247b5?w=500", "9.7k")
        )
    }

    // Dynamic infinite gradient offsets for that professional glowing neon button!
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_gradient")
    val gradientOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "offset"
    )

    val neonGradient = Brush.linearGradient(
        colors = listOf(ElectricPurple, NeonPink, ElectricPurple),
        start = Offset(gradientOffset, 0f),
        end = Offset(gradientOffset + 400f, 400f)
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Brush.horizontalGradient(listOf(ElectricPurple, NeonPink))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Logo Spark",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Text(
                            text = "PixCraft",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { /* Profile screen action */ }) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            AsyncImage(
                                model = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100",
                                contentDescription = "Profile Avatar",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                windowInsets = WindowInsets.navigationBars
            ) {
                NavigationBarItem(
                    selected = true,
                    onClick = { },
                    icon = { Icon(Icons.Filled.Home, "Home") },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { onStartEditing() },
                    icon = { Icon(Icons.Outlined.PhotoLibrary, "Gallery") },
                    label = { Text("Gallery") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { onStartEditing() },
                    icon = { Icon(Icons.Outlined.Edit, "Edit") },
                    label = { Text("Edit") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { },
                    icon = { Icon(Icons.Outlined.AutoAwesomeMosaic, "Templates") },
                    label = { Text("Layouts") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { },
                    icon = { Icon(Icons.Outlined.Person, "Profile") },
                    label = { Text("Profile") }
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
        ) {
            // 1. Stories row: Recent edits
            Text(
                text = "Recent Edits",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Add Quick Camera capture circle avatar first
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { onStartEditing() }
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(1.5.dp, ElectricPurple, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddAPhoto,
                            contentDescription = "New Camera Shoot",
                            tint = ElectricPurple,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Camera",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                recentEdits.forEach { edit ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { onStartEditing() }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .border(1.5.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                        ) {
                            AsyncImage(
                                model = edit.imageUrl,
                                contentDescription = edit.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (edit.title.length > 10) edit.title.take(8) + ".." else edit.title,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 2. Central Mega Glow Start Editing Button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    onClick = onStartEditing,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(84.dp)
                        .border(2.dp, neonGradient, RoundedCornerShape(20.dp))
                        .shadow(24.dp, spotColor = ElectricPurple, ambientColor = NeonPink)
                        .testTag("start_editing_button"),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141414))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 24.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Brush.radialGradient(listOf(ElectricPurple, Color.Transparent))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Sparkle Icon",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Start Editing",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Tap here to pick from gallery",
                                fontSize = 12.sp,
                                color = TextSecondaryDark
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ArrowForwardIos,
                            contentDescription = "Forward Sign",
                            tint = Color.White.copy(alpha = 0.7f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 3. Quick tools grid (2x3)
            Text(
                text = "Quick Tools",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(start = 20.dp, bottom = 12.dp)
            )

            // Grid Layout manually styled inside Scrollable Column
            val rows = quickTools.chunked(3)
            rows.forEach { rowItems ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    rowItems.forEach { tool ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(92.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable {
                                    onSelectQuickTool(tool.action)
                                }
                                .padding(12.dp)
                        ) {
                            if (tool.badge.isNotEmpty()) {
                                Badge(
                                    containerColor = if (tool.badge == "AI") ElectricPurple else NeonPink,
                                    modifier = Modifier.align(Alignment.TopEnd)
                                ) {
                                    Text(
                                        text = tool.badge,
                                        fontSize = 9.sp,
                                        color = Color.White,
                                        modifier = Modifier.padding(2.dp)
                                    )
                                }
                            }
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = tool.icon,
                                    contentDescription = tool.title,
                                    tint = ElectricPurple,
                                    modifier = Modifier.size(26.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = tool.title,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    textAlign = TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                    if (rowItems.size < 3) {
                        for (i in 0 until (3 - rowItems.size)) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 4. Trending templates horizontal list (dummy cards)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Trending Templates",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "See All",
                    fontSize = 12.sp,
                    color = ElectricPurple,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { /* See all action */ }
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                trendingTemplates.forEach { template ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .width(180.dp)
                            .height(240.dp)
                            .clickable { onStartEditing() },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            AsyncImage(
                                model = template.imageUrl,
                                contentDescription = template.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            // Top overlay button like picsart
                            Box(
                                modifier = Modifier
                                    .padding(8.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Black.copy(alpha = 0.6f))
                                    .align(Alignment.BottomStart)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Favorite,
                                        contentDescription = "Likes",
                                        tint = NeonPink,
                                        modifier = Modifier.size(10.dp)
                                    )
                                    Text(
                                        text = template.likes,
                                        fontSize = 9.sp,
                                        color = Color.White
                                    )
                                }
                            }
                            // Glow remix button
                            IconButton(
                                onClick = onStartEditing,
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(8.dp)
                                    .size(36.dp)
                                    .background(ElectricPurple, CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AutoAwesome,
                                    contentDescription = "Remix this",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
