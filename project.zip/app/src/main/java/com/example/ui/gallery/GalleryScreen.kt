package com.example.ui.gallery

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonPink
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL
import android.net.Uri
import android.os.Build
import android.graphics.ImageDecoder
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest

data class GalleryItem(
    val id: Int,
    val title: String,
    val imageUrl: String,
    val category: String, // edited, favorite, video, all
    val isVideo: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun GalleryScreen(
    onNavigateBack: () -> Unit,
    onPhotoSelected: (Bitmap) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            isLoading = true
            coroutineScope.launch {
                try {
                    val bitmap = withContext(Dispatchers.IO) {
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                                val source = ImageDecoder.createSource(context.contentResolver, uri)
                                ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                                    decoder.isMutableRequired = true
                                }
                            } else {
                                @Suppress("DEPRECATION")
                                val original = MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
                                original.copy(Bitmap.Config.ARGB_8888, true)
                            }
                        } catch (e: Exception) {
                            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                                BitmapFactory.decodeStream(inputStream)
                            }
                        }
                    }
                    if (bitmap != null) {
                        onPhotoSelected(bitmap)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                } finally {
                    isLoading = false
                }
            }
        }
    }

    val presetItems = remember {
        listOf(
            GalleryItem(1, "Neon Cyberpunk Portrait", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800", "all"),
            GalleryItem(2, "Warm Sunset Horizon", "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800", "all"),
            GalleryItem(3, "Minimal Slate Aesthetic", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800", "all"),
            GalleryItem(4, "Chromatic Double Exposure", "https://images.unsplash.com/photo-1511447333015-45b65e60f6d5?w=800", "edited"),
            GalleryItem(5, "Fuji Vintage Street", "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=800", "favorite"),
            GalleryItem(6, "Earthy Studio Bloom", "https://images.unsplash.com/photo-1526047932273-341f2a7631f9?w=800", "all"),
            GalleryItem(7, "Cosmic Night Haze", "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800", "favorite"),
            GalleryItem(8, "Vaporwave Retro Car", "https://images.unsplash.com/photo-1511919884226-fd3cad34687c?w=800", "all"),
            GalleryItem(9, "Cyberpunk Alley", "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=800", "edited"),
            GalleryItem(10, "Cinematic Video Frame", "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=800", "all", isVideo = true)
        )
    }

    var selectedTab by remember { mutableStateOf("All") }
    val tabs = remember { listOf("All", "Edited", "Favorites", "Videos") }

    // Multi-select session state
    var isMultiSelectActive by remember { mutableStateOf(false) }
    val selectedItemIds = remember { mutableStateListOf<Int>() }

    // Computes categorized list
    val filteredItems = remember(selectedTab) {
        when (selectedTab.lowercase()) {
            "all" -> presetItems
            "edited" -> presetItems.filter { it.category == "edited" }
            "favorites" -> presetItems.filter { it.category == "favorite" }
            "videos" -> presetItems.filter { it.isVideo }
            else -> presetItems
        }
    }

    // Downloads Bitmap from network safely inside co-routines to feed to Editor
    fun loadSelectedPhoto(url: String) {
        isLoading = true
        coroutineScope.launch {
            try {
                val bitmap = withContext(Dispatchers.IO) {
                    val connection = URL(url).openConnection()
                    connection.connectTimeout = 8000
                    connection.readTimeout = 8000
                    connection.doInput = true
                    val inputStream = connection.getInputStream()
                    BitmapFactory.decodeStream(inputStream)
                }
                if (bitmap != null) {
                    onPhotoSelected(bitmap)
                } else {
                    // Failover fallback bitmap creation
                    val fallback = Bitmap.createBitmap(800, 800, Bitmap.Config.ARGB_8888)
                    onPhotoSelected(fallback)
                }
            } catch (e: Exception) {
                // Network failover: Construct dummy high contrast gradient canvas
                val fallback = Bitmap.createBitmap(800, 800, Bitmap.Config.ARGB_8888)
                val canvas = android.graphics.Canvas(fallback)
                val paint = android.graphics.Paint().apply {
                    shader = android.graphics.LinearGradient(
                        0f, 0f, 800f, 800f,
                        android.graphics.Color.MAGENTA, android.graphics.Color.BLUE,
                        android.graphics.Shader.TileMode.CLAMP
                    )
                }
                canvas.drawRect(0f, 0f, 800f, 800f, paint)
                onPhotoSelected(fallback)
            } finally {
                isLoading = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isMultiSelectActive) "${selectedItemIds.size} Selected" else "Gallery",
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (isMultiSelectActive) {
                            isMultiSelectActive = false
                            selectedItemIds.clear()
                        } else {
                            onNavigateBack()
                        }
                    }) {
                        Icon(
                            imageVector = if (isMultiSelectActive) Icons.Default.Close else Icons.Default.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    if (isMultiSelectActive) {
                        IconButton(onClick = {
                            // Delete/merge multiple selected
                            isMultiSelectActive = false
                            selectedItemIds.clear()
                        }) {
                            Icon(Icons.Default.Delete, "Delete selection", tint = NeonPink)
                        }
                        IconButton(onClick = {
                            // Set favorite for all selected
                            isMultiSelectActive = false
                            selectedItemIds.clear()
                        }) {
                            Icon(Icons.Default.Favorite, "Favorite selection", tint = ElectricPurple)
                        }
                    } else {
                        IconButton(onClick = { /* Search gallery */ }) {
                            Icon(Icons.Default.Search, "Search")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                containerColor = ElectricPurple,
                contentColor = Color.White,
                shape = CircleShape
            ) {
                Icon(Icons.Default.AddPhotoAlternate, "Import Photo")
            }
        }
    ) { innerPadding ->
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.7f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = ElectricPurple)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Loading Canvas...",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            // Import from local device banner card
            Card(
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                border = androidx.compose.foundation.BorderStroke(
                    width = 1.dp,
                    brush = Brush.horizontalGradient(listOf(ElectricPurple, NeonPink))
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(Brush.horizontalGradient(listOf(ElectricPurple, NeonPink)), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = "Import icon",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Import Custom Photo",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Pick an image from your device gallery",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Choose image",
                        tint = ElectricPurple,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Top filter tab strip
            ScrollableTabRow(
                selectedTabIndex = tabs.indexOf(selectedTab).coerceAtLeast(0),
                containerColor = MaterialTheme.colorScheme.background,
                edgePadding = 16.dp,
                divider = {},
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[tabs.indexOf(selectedTab).coerceAtLeast(0)]),
                        color = ElectricPurple
                    )
                }
            ) {
                tabs.forEach { tabName ->
                    Tab(
                        selected = selectedTab == tabName,
                        onClick = { selectedTab = tabName },
                        text = {
                            Text(
                                text = tabName,
                                fontSize = 14.sp,
                                fontWeight = if (selectedTab == tabName) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 3-Column main structural Grid
            if (filteredItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Filter,
                            contentDescription = "Empty",
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No files found under $selectedTab",
                            color = MaterialTheme.colorScheme.outline,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentPadding = PaddingValues(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(filteredItems) { item ->
                        val isSelected = selectedItemIds.contains(item.id)
                        Box(
                            modifier = Modifier
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .combinedClickable(
                                    onClick = {
                                        if (isMultiSelectActive) {
                                            if (isSelected) {
                                                selectedItemIds.remove(item.id)
                                                if (selectedItemIds.isEmpty()) {
                                                    isMultiSelectActive = false
                                                }
                                            } else {
                                                selectedItemIds.add(item.id)
                                            }
                                        } else {
                                            loadSelectedPhoto(item.imageUrl)
                                        }
                                    },
                                    onLongClick = {
                                        isMultiSelectActive = true
                                        if (!isSelected) {
                                            selectedItemIds.add(item.id)
                                        }
                                    }
                                )
                        ) {
                            AsyncImage(
                                model = item.imageUrl,
                                contentDescription = item.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )

                            // Video Badge indicator
                            if (item.isVideo) {
                                Icon(
                                    imageVector = Icons.Default.PlayCircle,
                                    contentDescription = "Video file",
                                    tint = Color.White.copy(alpha = 0.9f),
                                    modifier = Modifier
                                        .size(24.dp)
                                        .align(Alignment.BottomStart)
                                        .padding(4.dp)
                                )
                            }

                            // Dark overlay when selected
                            if (isSelected) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.4f))
                                )
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(6.dp)
                                        .size(20.dp)
                                        .background(ElectricPurple, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Checked",
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
