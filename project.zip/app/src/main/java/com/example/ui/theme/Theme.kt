package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = ElectricPurple,
    onPrimary = Color.White,
    secondary = NeonPink,
    onSecondary = Color.White,
    tertiary = NeonPink,
    background = DeepBlack,
    onBackground = TextPrimaryDark,
    surface = SurfaceDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = TextSecondaryDark
  )

private val LightColorScheme = DarkColorScheme // Dark mode first, enforce dark theme for a creative tool

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force dark theme by default for creative aesthetic
  dynamicColor: Boolean = false, // Use our explicit design scheme for brand compliance
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
