package com.example.ui.editor

import android.graphics.Bitmap
import android.graphics.RectF
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.flow.StateFlow
import com.example.data.models.*
import com.example.ui.editor.canvas.EditorCanvas
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonPink
import com.example.ui.theme.SurfaceVariantDark
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    viewModel: EditorViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToExport: (Bitmap) -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val originalBitmap by viewModel.originalBitmap.collectAsStateWithLifecycle()
    val processedBitmap by viewModel.processedBitmap.collectAsStateWithLifecycle()
    val currentTool by viewModel.currentTool.collectAsStateWithLifecycle()

    // Editor detailed variables
    val brightness by viewModel.brightness.collectAsStateWithLifecycle()
    val contrast by viewModel.contrast.collectAsStateWithLifecycle()
    val saturation by viewModel.saturation.collectAsStateWithLifecycle()
    val warmth by viewModel.warmth.collectAsStateWithLifecycle()
    val vignette by viewModel.vignette.collectAsStateWithLifecycle()
    val sharpness by viewModel.sharpness.collectAsStateWithLifecycle()

    val selectedFilter by viewModel.selectedFilter.collectAsStateWithLifecycle()
    val filterIntensity by viewModel.filterIntensity.collectAsStateWithLifecycle()

    val skinSmooth by viewModel.skinSmooth.collectAsStateWithLifecycle()
    val skinBrighten by viewModel.skinBrighten.collectAsStateWithLifecycle()

    val brushSettings by viewModel.brushSettings.collectAsStateWithLifecycle()
    val strokes by viewModel.strokes.collectAsStateWithLifecycle()
    val activeStrokePoints by viewModel.activeStrokePoints.collectAsStateWithLifecycle()

    val textOverlays by viewModel.textOverlays.collectAsStateWithLifecycle()
    val selectedTextId by viewModel.selectedTextId.collectAsStateWithLifecycle()

    val stickerOverlays by viewModel.stickerOverlays.collectAsStateWithLifecycle()
    val selectedStickerId by viewModel.selectedStickerId.collectAsStateWithLifecycle()

    val liquifyBrushType by viewModel.liquifyBrushType.collectAsStateWithLifecycle()
    val liquifyRadius by viewModel.liquifyBrushRadius.collectAsStateWithLifecycle()
    val liquifyStrength by viewModel.liquifyBrushStrength.collectAsStateWithLifecycle()

    val rotation by viewModel.rotationDegrees.collectAsStateWithLifecycle()
    val isFlipH by viewModel.flipHorizontal.collectAsStateWithLifecycle()
    val isFlipV by viewModel.flipVertical.collectAsStateWithLifecycle()

    val overlayIntensity by viewModel.overlayIntensity.collectAsStateWithLifecycle()
    val overlayType by viewModel.overlayType.collectAsStateWithLifecycle()

    // State to toggle before/after comparison
    var showOriginalBeforeCompare by remember { mutableStateOf(false) }

    // Text Overlay adding sheet state
    var showTextDialog by remember { mutableStateOf(false) }
    var textInputState by remember { mutableStateOf("") }
    var textColorState by remember { mutableStateOf(Color.White) }

    // Categories list for bottom ribbon
    val categories = remember {
        listOf(
            "Adjust", "Filters", "Crop", "Brush", "Beauty", "Text", "Stickers", "Overlays", "Liquify", "Layers"
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "PixCraft Pro",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Navigate Back",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    // Compare Toggle (Touch down show original, touch up restore)
                    IconButton(
                        onClick = { },
                        modifier = Modifier
                            .testTag("compare_buttton")
                            .border(1.dp, Color.White.copy(alpha = 0.15f), CircleShape)
                    ) {
                        Icon(
                            imageVector = if (showOriginalBeforeCompare) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Compare",
                            tint = if (showOriginalBeforeCompare) NeonPink else Color.White,
                            modifier = Modifier
                                .size(20.dp)
                                .clickable {
                                    showOriginalBeforeCompare = !showOriginalBeforeCompare
                                }
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Undo state
                    IconButton(
                        onClick = { viewModel.undo() },
                        modifier = Modifier.border(1.dp, Color.White.copy(alpha = 0.12f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Undo,
                            contentDescription = "Undo",
                            tint = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Redo state
                    IconButton(
                        onClick = { viewModel.redo() },
                        modifier = Modifier.border(1.dp, Color.White.copy(alpha = 0.12f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Redo,
                            contentDescription = "Redo",
                            tint = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Export button
                    Button(
                        onClick = {
                            processedBitmap?.let { bitmap ->
                                onNavigateToExport(bitmap)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("export_button")
                    ) {
                        Icon(Icons.Filled.Publish, "Save icon", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Export", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0F0F0F)
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF050505))
                .padding(innerPadding)
        ) {
            // Main canvas viewport (top weight 1f)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                // Determine which bitmap to render: processed vs original compare
                val displayBitmap = if (showOriginalBeforeCompare) {
                    originalBitmap
                } else {
                    processedBitmap
                }

                if (displayBitmap != null) {
                    EditorCanvas(
                        bitmap = displayBitmap,
                        currentTool = currentTool,
                        strokes = strokes,
                        activeStrokePoints = activeStrokePoints,
                        textOverlays = textOverlays,
                        selectedTextId = selectedTextId,
                        stickerOverlays = stickerOverlays,
                        selectedStickerId = selectedStickerId,
                        brushSettings = brushSettings,
                        isLiquifyActive = currentTool.lowercase() == "liquify",
                        onBrushDrawStart = { pt -> viewModel.startBrushStroke(pt) },
                        onBrushDrawDrag = { pt -> viewModel.appendBrushStrokePoint(pt) },
                        onBrushDrawEnd = { viewModel.endBrushStroke() },
                        onUpdateTextOverlay = { item -> viewModel.updateTextOverlay(item) },
                        onSelectTextOverlay = { id -> viewModel.selectText(id) },
                        onUpdateSticker = { item -> viewModel.updateSticker(item) },
                        onSelectSticker = { id -> viewModel.selectSticker(id) },
                        onLiquifyDrag = { tx, ty, dx, dy -> viewModel.applyLiquifyWarpAt(tx, ty, dx, dy) },
                        showGrid = currentTool.lowercase() == "crop"
                    )
                } else {
                    // Loading loader overlay
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = ElectricPurple)
                    }
                }

                // Temporary watermark preview notice
                if (showOriginalBeforeCompare) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(16.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.7f))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("Original Preview Enabled", color = NeonPink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Sliders / Options panel depending on active category tab!
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F0F0F))
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                when (currentTool.lowercase()) {
                    "adjust" -> {
                        AdjustPanel(
                            brightness = brightness,
                            contrast = contrast,
                            saturation = saturation,
                            warmth = warmth,
                            vignette = vignette,
                            sharpness = sharpness,
                            onUpdateBrightness = { viewModel.updateBrightness(it) },
                            onUpdateContrast = { viewModel.updateContrast(it) },
                            onUpdateSaturation = { viewModel.updateSaturation(it) },
                            onUpdateWarmth = { viewModel.updateWarmth(it) },
                            onUpdateVignette = { viewModel.updateVignette(it) },
                            onUpdateSharpness = { viewModel.updateSharpness(it) }
                        )
                    }
                    "filters" -> {
                        FiltersPanel(
                            selectedFilter = selectedFilter,
                            intensity = filterIntensity,
                            onSelectFilter = { viewModel.selectFilter(it) },
                            onUpdateIntensity = { viewModel.filterIntensity.value = it }
                        )
                    }
                    "crop" -> {
                        CropPanel(
                            rotation = rotation,
                            isFlipH = isFlipH,
                            isFlipV = isFlipV,
                            onApplyPreset = { w, h -> viewModel.applyCropPreset(w, h) },
                            onRotate = { viewModel.rotate90() },
                            onToggleFlipH = { viewModel.toggleFlipHorizontal() },
                            onToggleFlipV = { viewModel.toggleFlipVertical() }
                        )
                    }
                    "brush" -> {
                        BrushPanel(
                            settings = brushSettings,
                            onUpdateSettings = { viewModel.updateBrushSettings(it) },
                            onClearStrokes = { viewModel.clearAllStrokes() }
                        )
                    }
                    "beauty" -> {
                        BeautyPanel(
                            skinSmooth = skinSmooth,
                            skinBrighten = skinBrighten,
                            onUpdateBeauty = { sm, br -> viewModel.updateSkinBeauty(sm, br) }
                        )
                    }
                    "text" -> {
                        TextPanel(
                            textOverlays = textOverlays,
                            selectedId = selectedTextId,
                            onAddClick = {
                                textInputState = ""
                                textColorState = Color.White
                                showTextDialog = true
                            },
                            onDeleteClick = { viewModel.deleteSelectedText() }
                        )
                    }
                    "stickers" -> {
                        StickersPanel(
                            onSelectSticker = { sticker -> viewModel.addSticker(sticker) }
                        )
                    }
                    "overlays" -> {
                        OverlaysPanel(
                            overlayType = overlayType,
                            intensity = overlayIntensity,
                            onSelectOverlay = { type, intensity -> viewModel.updateOverlay(type, intensity) }
                        )
                    }
                    "liquify" -> {
                        LiquifyPanel(
                            activeBrush = liquifyBrushType,
                            radius = liquifyRadius,
                            strength = liquifyStrength,
                            onSelectBrush = { viewModel.liquifyBrushType.value = it },
                            onUpdateRadius = { viewModel.liquifyBrushRadius.value = it },
                            onUpdateStrength = { viewModel.liquifyBrushStrength.value = it },
                            onReset = { viewModel.resetLiquifyMesh() }
                        )
                    }
                    "layers" -> {
                        LayersPanel(
                            textOverlays = textOverlays,
                            stickerOverlays = stickerOverlays,
                            strokes = strokes,
                            selectedTextId = selectedTextId,
                            selectedStickerId = selectedStickerId,
                            onSelectText = { viewModel.selectText(it) },
                            onSelectSticker = { viewModel.selectSticker(it) }
                        )
                    }
                }
            }

            // Bottom Horizontal Core Selection Ribbon
            ScrollableRowRibbon(
                items = categories,
                selectedItem = currentTool,
                onItemSelect = { viewModel.selectTool(it) }
            )
        }
    }

    // Modal adding Text Dialog
    if (showTextDialog) {
        AlertDialog(
            onDismissRequest = { showTextDialog = false },
            title = { Text("Add Text Caption", fontWeight = FontWeight.Bold, color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    TextField(
                        value = textInputState,
                        onValueChange = { textInputState = it },
                        placeholder = { Text("Enter words here..", color = Color.Gray) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = SurfaceVariantDark,
                            unfocusedContainerColor = SurfaceVariantDark
                        )
                    )

                    // Standard horizontal list of quick color choice squares
                    Text("Select Font Color", fontSize = 12.sp, color = TextSecondaryDark)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val palettes = listOf(Color.White, Color.Yellow, Color.Cyan, NeonPink, ElectricPurple, Color.Green, Color.Red)
                        palettes.forEach { clr ->
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(clr)
                                    .border(
                                        width = if (textColorState == clr) 2.dp else 0.dp,
                                        color = if (textColorState == clr) Color.Black else Color.Transparent,
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .clickable { textColorState = clr }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (textInputState.isNotEmpty()) {
                            viewModel.addTextOverlay(textInputState, textColorState)
                            showTextDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple)
                ) {
                    Text("Insert")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTextDialog = false }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = Color(0xFF141414)
        )
    }
}

@Composable
fun ScrollableRowRibbon(
    items: List<String>,
    selectedItem: String,
    onItemSelect: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .background(Color(0xFF0F0F0F))
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items.forEach { tag ->
            val isSelected = selectedItem.lowercase() == tag.lowercase()
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(32.dp))
                    .background(if (isSelected) ElectricPurple else Color.Transparent)
                    .clickable { onItemSelect(tag) }
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            ) {
                Text(
                    text = tag,
                    color = if (isSelected) Color.White else Color.Gray,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 13.sp
                )
            }
        }
    }
}

// --- OPTION PANELS COMPOSABLES ---

@Composable
fun AdjustPanel(
    brightness: Float,
    contrast: Float,
    saturation: Float,
    warmth: Float,
    vignette: Float,
    sharpness: Float,
    onUpdateBrightness: (Float) -> Unit,
    onUpdateContrast: (Float) -> Unit,
    onUpdateSaturation: (Float) -> Unit,
    onUpdateWarmth: (Float) -> Unit,
    onUpdateVignette: (Float) -> Unit,
    onUpdateSharpness: (Float) -> Unit
) {
    var activeAdjustTab by remember { mutableStateOf("Bright") }
    val tabs = listOf("Bright", "Contrast", "Saturate", "Warmth", "Vignette", "Sharp")

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Horizontal mini tab picker
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(tabs) { tab ->
                val isSelected = activeAdjustTab == tab
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) SurfaceVariantDark else Color.Transparent)
                        .clickable { activeAdjustTab = tab }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(tab, fontSize = 12.sp, color = if (isSelected) ElectricPurple else Color.LightGray)
                }
            }
        }

        // Selected option slider
        when (activeAdjustTab) {
            "Bright" -> SliderRow(label = "Brightness", value = brightness, min = -100f, max = 100f, onValueChange = onUpdateBrightness)
            "Contrast" -> SliderRow(label = "Contrast", value = contrast, min = -100f, max = 100f, onValueChange = onUpdateContrast)
            "Saturate" -> SliderRow(label = "Saturation", value = saturation, min = -100f, max = 100f, onValueChange = onUpdateSaturation)
            "Warmth" -> SliderRow(label = "Warmth", value = warmth, min = -100f, max = 100f, onValueChange = onUpdateWarmth)
            "Vignette" -> SliderRow(label = "Vignette Edge", value = vignette, min = 0f, max = 100f, onValueChange = onUpdateVignette)
            "Sharp" -> SliderRow(label = "Sharpness Detail", value = sharpness, min = 0f, max = 100f, onValueChange = onUpdateSharpness)
        }
    }
}

@Composable
fun SliderRow(
    label: String,
    value: Float,
    min: Float,
    max: Float,
    onValueChange: (Float) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("${value.toInt()}", fontSize = 13.sp, color = NeonPink, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = min..max,
            colors = SliderDefaults.colors(
                thumbColor = ElectricPurple,
                activeTrackColor = ElectricPurple,
                inactiveTrackColor = Color.DarkGray
            ),
            modifier = Modifier.testTag("${label.lowercase()}_slider")
        )
    }
}

@Composable
fun FiltersPanel(
    selectedFilter: String,
    intensity: Float,
    onSelectFilter: (String) -> Unit,
    onUpdateIntensity: (Float) -> Unit
) {
    val filters = remember {
        listOf("None", "Golden", "Cyberpunk", "Tokyo", "Film", "Noir", "Arctic", "Moody", "Vintage", "Sunset")
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Preview horizontal items
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(filters) { filter ->
                val isSelected = selectedFilter.lowercase() == filter.lowercase()
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { onSelectFilter(filter) }
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isSelected) Brush.verticalGradient(listOf(ElectricPurple, NeonPink))
                                else Brush.verticalGradient(listOf(Color(0xFF252525), Color(0xFF141414)))
                            )
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) ElectricPurple else Color.White.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(10.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        // Dynamic filter styling icons as preview
                        Icon(
                            imageVector = when (filter.lowercase()) {
                                "none" -> Icons.Default.FilterNone
                                "golden" -> Icons.Default.WbSunny
                                "cyberpunk" -> Icons.Default.Bolt
                                "tokyo" -> Icons.Default.Nightlife
                                "film" -> Icons.Default.Movie
                                "noir" -> Icons.Default.FilterBAndW
                                "arctic" -> Icons.Default.AcUnit
                                "moody" -> Icons.Default.Cloud
                                "vintage" -> Icons.Default.PhotoAlbum
                                else -> Icons.Default.Landscape
                            },
                            contentDescription = filter,
                            tint = if (isSelected) Color.White else Color.Gray,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = filter,
                        fontSize = 11.sp,
                        color = if (isSelected) Color.White else Color.Gray,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }

        if (selectedFilter != "None") {
            SliderRow(label = "Filter Strength", value = intensity, min = 0f, max = 100f, onValueChange = onUpdateIntensity)
        }
    }
}

@Composable
fun CropPanel(
    rotation: Float,
    isFlipH: Boolean,
    isFlipV: Boolean,
    onApplyPreset: (Float, Float) -> Unit,
    onRotate: () -> Unit,
    onToggleFlipH: () -> Unit,
    onToggleFlipV: () -> Unit
) {
    val presets = listOf(
        "Free" to (0f to 0f),
        "1:1 Square" to (1f to 1f),
        "4:3 Classic" to (4f to 3f),
        "16:9 Cinema" to (16f to 9f),
        "9:16 Tiktok" to (9f to 16f)
    )

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Presets list tabs
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(presets) { pair ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(SurfaceVariantDark)
                        .clickable { onApplyPreset(pair.second.first, pair.second.second) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(pair.first, fontSize = 11.sp, color = Color.White)
                }
            }
        }

        // Pivot Transformations Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onRotate, modifier = Modifier.background(SurfaceVariantDark, CircleShape)) {
                Icon(Icons.Filled.RotateRight, "Rotate 90", tint = Color.White)
            }
            IconButton(onClick = onToggleFlipH, modifier = Modifier.background(if (isFlipH) ElectricPurple else SurfaceVariantDark, CircleShape)) {
                Icon(Icons.Filled.Flip, "Flip Horizonal", tint = Color.White)
            }
            IconButton(onClick = onToggleFlipV, modifier = Modifier.background(if (isFlipV) NeonPink else SurfaceVariantDark, CircleShape)) {
                Icon(Icons.Filled.SwapVert, "Flip Vertical", tint = Color.White)
            }
        }
    }
}

@Composable
fun BrushPanel(
    settings: BrushSettings,
    onUpdateSettings: (BrushSettings) -> Unit,
    onClearStrokes: () -> Unit
) {
    val brushTypes = listOf("Basic Round", "Soft Round", "Airbrush", "Marker")

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Eraser Toggle Button
            Button(
                onClick = { onUpdateSettings(settings.copy(isEraser = !settings.isEraser)) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (settings.isEraser) NeonPink else SurfaceVariantDark
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.CleaningServices, "Eraser", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (settings.isEraser) "Eraser Active" else "Use Eraser", fontSize = 12.sp)
            }

            // Reset Button
            TextButton(onClick = onClearStrokes) {
                Text("Clear Drawing", color = NeonPink, fontSize = 12.sp)
            }
        }

        // Brush Type Picker
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(brushTypes) { btn ->
                val isSelected = settings.brushType == btn && !settings.isEraser
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) ElectricPurple else SurfaceVariantDark)
                        .clickable { onUpdateSettings(settings.copy(brushType = btn, isEraser = false)) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(btn, fontSize = 12.sp, color = Color.White)
                }
            }
        }

        // Color Presets choosing row
        Text("Brush Color Palette", fontSize = 11.sp, color = TextSecondaryDark)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val palettes = listOf(Color(0xFF7B2FFF), Color(0xFFFF2D78), Color.Cyan, Color.Yellow, Color.White, Color.Green, Color.Red, Color.Black)
            palettes.forEach { clr ->
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(clr)
                        .border(
                            width = if (settings.color == clr) 2.dp else 0.dp,
                            color = Color.White,
                            shape = CircleShape
                        )
                        .clickable { onUpdateSettings(settings.copy(color = clr, isEraser = false)) }
                )
            }
        }

        // size & opacity sliders
        SliderRow(label = "Brush Size px", value = settings.size, min = 5f, max = 200f, onValueChange = { onUpdateSettings(settings.copy(size = it)) })
        SliderRow(label = "Brush Opacity %", value = settings.opacity * 100f, min = 0f, max = 100f, onValueChange = { onUpdateSettings(settings.copy(opacity = it / 100f)) })
    }
}

@Composable
fun BeautyPanel(
    skinSmooth: Float,
    skinBrighten: Float,
    onUpdateBeauty: (Float, Float) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        SliderRow(label = "Skin Soft Smooth", value = skinSmooth, min = 0f, max = 100f, onValueChange = { onUpdateBeauty(it, skinBrighten) })
        SliderRow(label = "Face Skin Brighten", value = skinBrighten, min = 0f, max = 100f, onValueChange = { onUpdateBeauty(skinSmooth, it) })
    }
}

@Composable
fun TextPanel(
    textOverlays: List<TextOverlay>,
    selectedId: UUID?,
    onAddClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Button(
            onClick = onAddClick,
            colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(Icons.Filled.TextFields, "Add Text", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Insert Floating Text", fontSize = 12.sp)
        }

        if (selectedId != null) {
            Button(
                onClick = onDeleteClick,
                colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Delete, "Delete")
                Spacer(modifier = Modifier.width(6.dp))
                Text("Delete Selected", fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun StickersPanel(
    onSelectSticker: (String) -> Unit
) {
    val stickersList = listOf(
        "🌸", "⚡", "✨", "🔥", "🦄", "🌈", "😈", "🍭", "👽", "🍟", "🍕", "🎭", "🎪", "🎃", "🎬", "🎸", "👑"
    )

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Tap stickers to place on image", fontSize = 11.sp, color = TextSecondaryDark)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(stickersList) { emoji ->
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(SurfaceVariantDark)
                        .clickable { onSelectSticker(emoji) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(emoji, fontSize = 28.sp)
                }
            }
        }
    }
}

@Composable
fun OverlaysPanel(
    overlayType: String,
    intensity: Float,
    onSelectOverlay: (String, Float) -> Unit
) {
    val typesList = listOf("None", "Light Leak", "Film Grain", "Bokeh")

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(typesList) { option ->
                val isSelected = overlayType == option
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) ElectricPurple else SurfaceVariantDark)
                        .clickable { onSelectOverlay(option, if (option == "None") 0f else 50f) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(option, fontSize = 12.sp, color = Color.White)
                }
            }
        }

        if (overlayType != "None") {
            SliderRow(
                label = "Overlay Darkness/Level",
                value = intensity,
                min = 0f,
                max = 100f,
                onValueChange = { onSelectOverlay(overlayType, it) }
            )
        }
    }
}

@Composable
fun LiquifyPanel(
    activeBrush: String,
    radius: Float,
    strength: Float,
    onSelectBrush: (String) -> Unit,
    onUpdateRadius: (Float) -> Unit,
    onUpdateStrength: (Float) -> Unit,
    onReset: () -> Unit
) {
    val brushModes = listOf(
        "push" to "Push Shift",
        "expand" to "Bloat",
        "contract" to "Pinch",
        "twirl" to "Twirl"
    )

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Liquify Warp Engine", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ElectricPurple)
            TextButton(onClick = onReset) {
                Text("Restore Mesh", color = NeonPink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(brushModes) { mode ->
                val isSelected = activeBrush == mode.first
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) ElectricPurple else SurfaceVariantDark)
                        .clickable { onSelectBrush(mode.first) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(mode.second, fontSize = 11.sp, color = Color.White)
                }
            }
        }

        SliderRow(label = "Brush Warp Radius", value = radius, min = 50f, max = 400f, onValueChange = onUpdateRadius)
        SliderRow(label = "Warp Impact Factor", value = strength * 100f, min = 0f, max = 100f, onValueChange = { onUpdateStrength(it / 100f) })
    }
}

@Composable
fun LayersPanel(
    textOverlays: List<TextOverlay>,
    stickerOverlays: List<StickerOverlay>,
    strokes: List<com.example.data.models.DrawingStroke>,
    selectedTextId: UUID?,
    selectedStickerId: UUID?,
    onSelectText: (UUID?) -> Unit,
    onSelectSticker: (UUID?) -> Unit
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 140.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Creative Vectors Layers Pile", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)

        if (textOverlays.isEmpty() && stickerOverlays.isEmpty() && strokes.isEmpty()) {
            Text("Only Base Image compiled on background", fontSize = 11.sp, color = Color.Gray)
        }

        // Draw Layer elements
        if (strokes.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.White.copy(alpha = 0.04f))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Brush, "Draw icon", tint = ElectricPurple, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Hand Drawing Overlay (${strokes.size} paths)", fontSize = 12.sp, color = Color.LightGray)
            }
        }

        textOverlays.filter { it.text.isNotEmpty() }.forEach { text ->
            val isSelected = selectedTextId == text.id
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isSelected) Color.White.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.04f))
                    .clickable { onSelectText(text.id) }
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Title, "Text Layer Icon", tint = NeonPink, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Text Layer: \"${text.text}\"", fontSize = 12.sp, color = Color.LightGray, modifier = Modifier.weight(1f))
                if (isSelected) {
                    Box(modifier = Modifier.size(8.dp).background(ElectricPurple, CircleShape))
                }
            }
        }

        stickerOverlays.filter { it.stickerName.isNotEmpty() }.forEach { sticker ->
            val isSelected = selectedStickerId == sticker.id
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isSelected) Color.White.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.04f))
                    .clickable { onSelectSticker(sticker.id) }
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.EmojiEmotions, "Stickers Layer Icon", tint = Color.Yellow, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Sticker Layer: ${sticker.stickerName}", fontSize = 12.sp, color = Color.LightGray, modifier = Modifier.weight(1f))
                if (isSelected) {
                    Box(modifier = Modifier.size(8.dp).background(NeonPink, CircleShape))
                }
            }
        }
    }
}
