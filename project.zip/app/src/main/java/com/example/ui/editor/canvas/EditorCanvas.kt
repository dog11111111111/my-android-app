package com.example.ui.editor.canvas

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.graphics.drawscope.clipRect
import com.example.data.models.BrushSettings
import com.example.data.models.DrawingStroke
import com.example.data.models.StickerOverlay
import com.example.data.models.TextOverlay
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NeonPink
import java.util.UUID
import kotlin.math.PI
import kotlin.math.atan2

@Composable
fun EditorCanvas(
    bitmap: Bitmap,
    currentTool: String,
    strokes: List<DrawingStroke>,
    activeStrokePoints: List<Offset>,
    textOverlays: List<TextOverlay>,
    selectedTextId: UUID?,
    stickerOverlays: List<StickerOverlay>,
    selectedStickerId: UUID?,
    brushSettings: BrushSettings,
    isLiquifyActive: Boolean,
    onBrushDrawStart: (Offset) -> Unit,
    onBrushDrawDrag: (Offset) -> Unit,
    onBrushDrawEnd: () -> Unit,
    onUpdateTextOverlay: (TextOverlay) -> Unit,
    onSelectTextOverlay: (UUID?) -> Unit,
    onUpdateSticker: (StickerOverlay) -> Unit,
    onSelectSticker: (UUID?) -> Unit,
    onLiquifyDrag: (Float, Float, Float, Float) -> Unit, // touchX, touchY, dx, dy
    showGrid: Boolean = false
) {
    // Zoom & Pan state
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    // Double tap reset
    val state = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(0.5f, 10f)
        offset += offsetChange * scale
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clipToBounds()
            .background(Color(0xFF030303))
            // 2-finger zoom/pan gestures
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = {
                        scale = 1f
                        offset = Offset.Zero
                    },
                    onTap = {
                        // Deselect layer on clicking empty canvas space
                        onSelectTextOverlay(null)
                        onSelectSticker(null)
                    }
                )
            }
            .pointerInput(currentTool, isLiquifyActive) {
                // If draw, liquify or move details are active, we route single finger tap, else we do standard pan
                if (currentTool.lowercase() == "draw" || currentTool.lowercase() == "liquify") {
                    detectDragGestures(
                        onDragStart = { startOffset ->
                            val localPoint = translateTouchPoint(startOffset, scale, offset, Size(size.width.toFloat(), size.height.toFloat()))
                            if (currentTool.lowercase() == "draw") {
                                onBrushDrawStart(localPoint)
                            }
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val localPoint = translateTouchPoint(change.position, scale, offset, Size(size.width.toFloat(), size.height.toFloat()))
                            if (currentTool.lowercase() == "draw") {
                                onBrushDrawDrag(localPoint)
                            } else if (currentTool.lowercase() == "liquify") {
                                // Liquify push warp
                                onLiquifyDrag(localPoint.x, localPoint.y, dragAmount.x / scale, dragAmount.y / scale)
                            }
                        },
                        onDragEnd = {
                            if (currentTool.lowercase() == "draw") {
                                onBrushDrawEnd()
                            }
                        }
                    )
                }
            }
    ) {
        // Main zoomable canvas wrapping content
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    translationX = offset.x,
                    translationY = offset.y
                )
                .transformable(state = state)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(textOverlays, selectedTextId, scale) {
                        // Handle dragging / transforming text vectors
                        detectDragGestures(
                            onDragStart = { startOffset ->
                                val localPoint = translateTouchPoint(startOffset, 1f, Offset.Zero, Size(size.width.toFloat(), size.height.toFloat()))
                                val hitText = textOverlays.lastOrNull { text ->
                                    val dist = (localPoint - text.position).getDistance()
                                    dist < 120f // Hit radius
                                }
                                if (hitText != null) {
                                    onSelectTextOverlay(hitText.id)
                                    onSelectSticker(null)
                                }
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                selectedTextId?.let { id ->
                                    val current = textOverlays.firstOrNull { it.id == id } ?: return@let
                                    onUpdateTextOverlay(
                                        current.copy(
                                            position = current.position + dragAmount
                                        )
                                    )
                                }
                            }
                        )
                    }
                    .pointerInput(stickerOverlays, selectedStickerId, scale) {
                        // Handle dragging stickers
                        detectDragGestures(
                            onDragStart = { startOffset ->
                                val localPoint = translateTouchPoint(startOffset, 1f, Offset.Zero, Size(size.width.toFloat(), size.height.toFloat()))
                                val hitSticker = stickerOverlays.lastOrNull { stick ->
                                    val dist = (localPoint - stick.position).getDistance()
                                    dist < 120f
                                }
                                if (hitSticker != null) {
                                    onSelectSticker(hitSticker.id)
                                    onSelectTextOverlay(null)
                                }
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                selectedStickerId?.let { id ->
                                    val current = stickerOverlays.firstOrNull { it.id == id } ?: return@let
                                    onUpdateSticker(
                                        current.copy(
                                            position = current.position + dragAmount
                                        )
                                    )
                                }
                            }
                        )
                    }
            ) {
                // Centering the edited photo bitmap on Compose canvas safely
                val canvasW = size.width
                val canvasH = size.height

                val bW = bitmap.width.toFloat()
                val bH = bitmap.height.toFloat()

                val scaleX = canvasW / bW
                val scaleY = canvasH / bH
                val fitScale = minOf(scaleX, scaleY) * 0.9f

                val drawW = bW * fitScale
                val drawH = bH * fitScale

                val startX = (canvasW - drawW) / 2f
                val startY = (canvasH - drawH) / 2f

                // Draw base processed bitmap
                drawImage(
                    image = bitmap.asImageBitmap(),
                    dstOffset = IntOffset(startX.toInt(), startY.toInt()),
                    dstSize = IntSize(drawW.toInt(), drawH.toInt()),
                    filterQuality = FilterQuality.High
                )

                // Draw Historic Brush Strokes (Relative to original scale, translated)
                clipRect(startX, startY, startX + drawW, startY + drawH) {
                    // Render historical background strokes
                    strokes.forEach { stroke ->
                        drawStrokeOnCanvas(stroke, startX, startY, fitScale, bW, bH)
                    }

                    // Render active brush stroke
                    if (activeStrokePoints.isNotEmpty()) {
                        val activeStroke = DrawingStroke(
                            points = activeStrokePoints,
                            settings = brushSettings
                        )
                        drawStrokeOnCanvas(activeStroke, startX, startY, fitScale, bW, bH)
                    }
                }

                // Draw Text overlays vector
                textOverlays.forEach { textOverlay ->
                    val textPaint = Paint().asFrameworkPaint().apply {
                        isAntiAlias = true
                        textSize = textOverlay.size * fitScale * 0.15f
                        color = textOverlay.color.toArgb()
                        typeface = android.graphics.Typeface.create(
                            textOverlay.fontName,
                            if (textOverlay.isBold && textOverlay.isItalic) android.graphics.Typeface.BOLD_ITALIC
                            else if (textOverlay.isBold) android.graphics.Typeface.BOLD
                            else if (textOverlay.isItalic) android.graphics.Typeface.ITALIC
                            else android.graphics.Typeface.NORMAL
                        )
                    }

                    drawContext.canvas.nativeCanvas.save()
                    // Translate relative to fit bitmap
                    val absX = startX + (textOverlay.position.x / bW) * drawW
                    val absY = startY + (textOverlay.position.y / bH) * drawH

                    drawContext.canvas.nativeCanvas.rotate(textOverlay.rotation, absX, absY)

                    // Draw shadow simulation if requested
                    if (textOverlay.hasShadow) {
                        textPaint.setShadowLayer(8f, 4f, 4f, textOverlay.shadowColor.toArgb())
                    }

                    drawContext.canvas.nativeCanvas.drawText(
                        textOverlay.text,
                        absX,
                        absY,
                        textPaint
                    )
                    drawContext.canvas.nativeCanvas.restore()

                    // Draw selection bounding outline box for active item
                    if (selectedTextId == textOverlay.id) {
                        drawRect(
                            color = ElectricPurple,
                            topLeft = Offset(absX - 40f, absY - 80f),
                            size = Size(textPaint.measureText(textOverlay.text) + 80f, 110f),
                            style = Stroke(2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f))
                        )
                    }
                }

                // Draw Stickers/Emoji overlays
                stickerOverlays.forEach { sticker ->
                    val stickerPaint = Paint().asFrameworkPaint().apply {
                        isAntiAlias = true
                        textSize = 100f * sticker.scale * fitScale * 0.15f
                    }

                    val absX = startX + (sticker.position.x / bW) * drawW
                    val absY = startY + (sticker.position.y / bH) * drawH

                    drawContext.canvas.nativeCanvas.save()
                    drawContext.canvas.nativeCanvas.rotate(sticker.rotation, absX, absY)

                    // StickerName contains emoji or path
                    drawContext.canvas.nativeCanvas.drawText(
                        sticker.stickerName,
                        absX,
                        absY,
                        stickerPaint
                    )
                    drawContext.canvas.nativeCanvas.restore()

                    if (selectedStickerId == sticker.id) {
                        drawCircle(
                            color = NeonPink,
                            radius = 60f * sticker.scale,
                            center = Offset(absX, absY - 30f),
                            style = Stroke(2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 5f), 0f))
                        )
                    }
                }

                // 4. Rule of thirds Grid Layout Overlay Guide
                if (showGrid) {
                    val strokeColor = Color.White.copy(alpha = 0.5f)
                    val gridWidth = 1.5f
                    // Columns
                    drawLine(
                        color = strokeColor,
                        strokeWidth = gridWidth,
                        start = Offset(startX + drawW / 3f, startY),
                        end = Offset(startX + drawW / 3f, startY + drawH)
                    )
                    drawLine(
                        color = strokeColor,
                        strokeWidth = gridWidth,
                        start = Offset(startX + drawW * 2f / 3f, startY),
                        end = Offset(startX + drawW * 2f / 3f, startY + drawH)
                    )
                    // Rows
                    drawLine(
                        color = strokeColor,
                        strokeWidth = gridWidth,
                        start = Offset(startX, startY + drawH / 3f),
                        end = Offset(startX + drawW, startY + drawH / 3f)
                    )
                    drawLine(
                        color = strokeColor,
                        strokeWidth = gridWidth,
                        start = Offset(startX, startY + drawH * 2f / 3f),
                        end = Offset(startX + drawW, startY + drawH * 2f / 3f)
                    )
                }
            }
        }

        // Layer floating quick controls when a Text or sticker is selected
        if (selectedTextId != null) {
            val selectedItem = textOverlays.firstOrNull { it.id == selectedTextId }
            selectedItem?.let { txt ->
                QuickActionFloatingPanel(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 80.dp),
                    onDelete = { onSelectTextOverlay(null); deleteSelectedText(txt, onUpdateTextOverlay) },
                    onRotate = {
                        onUpdateTextOverlay(txt.copy(rotation = (txt.rotation + 15f) % 360f))
                    },
                    onScaleUp = {
                        onUpdateTextOverlay(txt.copy(size = (txt.size + 4f).coerceIn(12f, 300f)))
                    },
                    onScaleDown = {
                        onUpdateTextOverlay(txt.copy(size = (txt.size - 4f).coerceIn(12f, 300f)))
                    }
                )
            }
        } else if (selectedStickerId != null) {
            val selectedStick = stickerOverlays.firstOrNull { it.id == selectedStickerId }
            selectedStick?.let { stick ->
                QuickActionFloatingPanel(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 80.dp),
                    onDelete = { onSelectSticker(null); deleteSelectedSticker(stick, onUpdateSticker) },
                    onRotate = {
                        onUpdateSticker(stick.copy(rotation = (stick.rotation + 15f) % 360f))
                    },
                    onScaleUp = {
                        onUpdateSticker(stick.copy(scale = (stick.scale + 0.15f).coerceIn(0.2f, 10f)))
                    },
                    onScaleDown = {
                        onUpdateSticker(stick.copy(scale = (stick.scale - 0.15f).coerceIn(0.2f, 10f)))
                    }
                )
            }
        }
    }
}

// Multi-finger safe location mapper
private fun translateTouchPoint(
    localPoint: Offset,
    scale: Float,
    offset: Offset,
    canvasSize: Size
): Offset {
    // Standard inverse coordinate mapping to track true pixels on base image
    val relativeX = (localPoint.x - offset.x) / scale
    val relativeY = (localPoint.y - offset.y) / scale
    return Offset(relativeX, relativeY)
}

// Clean helper to draw brush stroke paths onto Compose Canvas safely
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawStrokeOnCanvas(
    stroke: DrawingStroke,
    startX: Float,
    startY: Float,
    fitScale: Float,
    bW: Float,
    bH: Float
) {
    if (stroke.points.size < 2) return
    val path = Path()

    // Map starting coordinate
    val startPt = mapToCanvas(stroke.points[0], startX, startY, fitScale, bW, bH)
    path.moveTo(startPt.x, startPt.y)

    for (i in 1 until stroke.points.size) {
        val mappedPt = mapToCanvas(stroke.points[i], startX, startY, fitScale, bW, bH)
        path.lineTo(mappedPt.x, mappedPt.y)
    }

    drawPath(
        path = path,
        color = stroke.settings.color.copy(alpha = stroke.settings.opacity),
        style = Stroke(
            width = stroke.settings.size * fitScale * 0.4f,
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        ),
        blendMode = if (stroke.settings.isEraser) BlendMode.Clear else BlendMode.SrcOver
    )
}

private fun mapToCanvas(pt: Offset, startX: Float, startY: Float, fitScale: Float, bW: Float, bH: Float): Offset {
    // If double exposure adjustments or transforms are applied we scale accordingly
    // The points are recorded relative to the actual loaded bitmap coordinates (0 to bW, 0 to bH)
    val cx = startX + (pt.x / bW) * (bW * fitScale)
    val cy = startY + (pt.y / bH) * (bH * fitScale)
    return Offset(cx, cy)
}

private fun deleteSelectedText(text: TextOverlay, update: (TextOverlay) -> Unit) {
    update(text.copy(text = "")) // Signal delete in parent ViewModel
}

private fun deleteSelectedSticker(sticker: StickerOverlay, update: (StickerOverlay) -> Unit) {
    update(sticker.copy(stickerName = "")) // Signal delete in parent ViewModel
}

@Composable
fun QuickActionFloatingPanel(
    modifier: Modifier = Modifier,
    onDelete: () -> Unit,
    onRotate: () -> Unit,
    onScaleUp: () -> Unit,
    onScaleDown: () -> Unit
) {
    Surface(
        modifier = modifier
            .wrapContentWidth()
            .height(54.dp)
            .background(Color.Transparent),
        shape = RoundedCornerShape(27.dp),
        color = Color(0xE6141414),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxHeight()
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, "Delete Layer", tint = NeonPink)
            }
            VerticalDivider(modifier = Modifier.height(24.dp), color = Color.White.copy(alpha = 0.2f))
            IconButton(onClick = onRotate) {
                Icon(Icons.Filled.Cached, "Rotate Vector", tint = Color.White)
            }
            IconButton(onClick = onScaleUp) {
                Text("+", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
            }
            IconButton(onClick = onScaleDown) {
                Text("-", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
            }
        }
    }
}
