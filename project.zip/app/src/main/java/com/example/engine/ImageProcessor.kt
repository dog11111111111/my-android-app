package com.example.engine

import android.graphics.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlin.math.*

object ImageProcessor {

    /**
     * Applies fundamental real-time adjustments (Brightness, Contrast, Saturation, Warmth, Tint, Vignette, Sharpness)
     * using hardware-accelerated Canvas/ColorMatrix operations where possible.
     */
    fun applyAdjustments(
        base: Bitmap,
        brightness: Float, // -100 to +100
        contrast: Float,   // -100 to +100
        saturation: Float, // -100 to +100
        warmth: Float,     // -100 to +100 (yellow to blue)
        vignette: Float,   // 0 to 100
        sharpness: Float   // 0 to 100
    ): Bitmap {
        val width = base.width
        val height = base.height
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        // 1. ColorMatrix Color correction
        val cm = ColorMatrix()

        // Brightness: scale and offset (using standard contrast offsets)
        val bFactor = brightness / 255f
        val brightnessMatrix = ColorMatrix(floatArrayOf(
            1f, 0f, 0f, 0f, bFactor * 255f,
            0f, 1f, 0f, 0f, bFactor * 255f,
            0f, 0f, 1f, 0f, bFactor * 255f,
            0f, 0f, 0f, 1f, 0f
        ))
        cm.postConcat(brightnessMatrix)

        // Contrast: scale about center 128
        val cFactor = if (contrast >= 0) {
            1f + (contrast / 100f) * 1.5f
        } else {
            1f + (contrast / 100f) * 0.8f
        }
        val t = (1f - cFactor) * 128f
        val contrastMatrix = ColorMatrix(floatArrayOf(
            cFactor, 0f, 0f, 0f, t,
            0f, cFactor, 0f, 0f, t,
            0f, 0f, cFactor, 0f, t,
            0f, 0f, 0f, 1f, 0f
        ))
        cm.postConcat(contrastMatrix)

        // Saturation:
        val sFactor = if (saturation >= 0) {
            1f + (saturation / 100f) * 1.5f
        } else {
            1f + (saturation / 100f) * 1.0f
        }
        val satMatrix = ColorMatrix().apply { setSaturation(sFactor) }
        cm.postConcat(satMatrix)

        // Warmth (White Balance) correction
        val wFactor = warmth / 100f * 40f
        val warmthMatrix = ColorMatrix(floatArrayOf(
            1f + wFactor/255f, 0f, 0f, 0f, wFactor,
            0f, 1f, 0f, 0f, 0f,
            0f, 0f, 1f - wFactor/255f, 0f, -wFactor,
            0f, 0f, 0f, 1f, 0f
        ))
        cm.postConcat(warmthMatrix)

        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(base, 0f, 0f, paint)

        // 2. Vignette Layer
        if (vignette > 0f) {
            val vPaint = Paint(Paint.ANTI_ALIAS_FLAG)
            val radius = sqrt((width * width + height * height).toDouble()).toFloat() * 0.5f
            val darkness = (vignette / 100f) * 0.85f // max dark 85% opacity at edges
            val colors = intArrayOf(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.argb((darkness * 255).toInt(), 0, 0, 0)
            )
            val stops = floatArrayOf(0.0f, 0.4f, 1.0f)
            vPaint.shader = RadialGradient(
                width / 2f, height / 2f, radius,
                colors, stops, Shader.TileMode.CLAMP
            )
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), vPaint)
        }

        // 3. Sharpness (Convolve/Unsharp Mask simulation on Canvas via secondary draw offsets)
        if (sharpness > 0f) {
            val finalOutput = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val finalCanvas = Canvas(finalOutput)
            val sharpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            finalCanvas.drawBitmap(output, 0f, 0f, sharpPaint)

            // Simulate sharpness by blending high-pass offset differences
            val offset = 1.0f + (sharpness / 100f) * 1.5f
            sharpPaint.alpha = (sharpness * 0.7f).toInt()
            
            // Draw duplicate slightly offset to highlight high frequency edges
            val matrix = Matrix()
            finalCanvas.drawBitmap(output, -offset, 0f, sharpPaint)
            finalCanvas.drawBitmap(output, offset, 0f, sharpPaint)
            finalCanvas.drawBitmap(output, 0f, -offset, sharpPaint)
            finalCanvas.drawBitmap(output, 0f, offset, sharpPaint)
            
            // Restore opacity and draw original atop
            sharpPaint.alpha = 255
            return finalOutput
        }

        return output
    }

    /**
     * Core Filter Presets containing standard color configurations.
     */
    fun applyFilterPreset(base: Bitmap, filterName: String): Bitmap {
        val width = base.width
        val height = base.height
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        val cm = ColorMatrix()
        when (filterName.lowercase()) {
            "golden", "golden hour" -> {
                // Warm sunset hue with high saturation and golden undertones
                cm.setConcat(
                    ColorMatrix(floatArrayOf(
                        1.2f, 0f, 0f, 0f, 25f,
                        0f, 1.05f, 0f, 0f, 10f,
                        0f, 0f, 0.8f, 0f, -20f,
                        0f, 0f, 0f, 1f, 0f
                    )),
                    ColorMatrix().apply { setSaturation(1.4f) }
                )
            }
            "cyberpunk", "neon" -> {
                // High contrast cyan shadows and magenta highlights
                cm.setConcat(
                    ColorMatrix(floatArrayOf(
                        1.1f, 0f, 0.2f, 0f, 40f,  // boost red for magenta highlights
                        0f, 0.8f, 0f, 0f, -10f,
                        0.2f, 0f, 1.3f, 0f, 35f,  // boost blue
                        0f, 0f, 0f, 1f, 0f
                    )),
                    ColorMatrix().apply { setSaturation(1.5f) }
                )
            }
            "teal-orange", "tokyo" -> {
                // Dual tone splitting: oranges in highlights, blue-greens in shadows
                cm.setConcat(
                    ColorMatrix(floatArrayOf(
                        1.25f, 0f, 0f, 0f, 15f,
                        0f, 1.0f, 0f, 0f, 5f,
                        0f, 0f, 1.2f, 0f, -10f,
                        0f, 0f, 0f, 1f, 0f
                    )),
                    ColorMatrix(floatArrayOf(
                        1.0f, 0.0f, -0.1f, 0.0f, 0.0f,
                        0.0f, 1.1f, 0.0f, 0.0f, 10.0f,
                        -0.1f, 0.1f, 1.2f, 0.0f, 20.0f,
                        0.0f, 0.0f, 0.0f, 1.0f, 0.0f
                    ))
                )
            }
            "film", "retro" -> {
                // Fade effect (reduced black point), slightly green highlights, organic warm tone
                cm.setConcat(
                    ColorMatrix(floatArrayOf(
                        0.95f, 0f, 0f, 0f, 20f,
                        0f, 0.95f, 0f, 0f, 15f,
                        0f, 0f, 0.9f, 0f, 10f,
                        0f, 0f, 0f, 1f, 0f
                    )),
                    ColorMatrix(floatArrayOf(
                        0.9f, 0f, 0f, 0f, 15f,
                        0f, 0.95f, 0f, 0f, 10f,
                        0f, 0f, 0.9f, 0f, 5f,
                        0f, 0f, 0f, 1f, 30f // fade effect
                    ))
                )
            }
            "noir", "black & white" -> {
                // Contrast-heavy monochromatic Noir look
                cm.setConcat(
                    ColorMatrix().apply { setSaturation(0f) },
                    ColorMatrix(floatArrayOf(
                        1.4f, 0f, 0f, 0f, -25f,
                        0f, 1.4f, 0f, 0f, -25f,
                        0f, 0f, 1.4f, 0f, -25f,
                        0f, 0f, 0f, 1f, 0f
                    ))
                )
            }
            "arctic", "cool" -> {
                // Monotone blue saturation with bright highlights
                cm.setConcat(
                    ColorMatrix(floatArrayOf(
                        0.8f, 0f, 0f, 0f, -15f,
                        0f, 0.95f, 0f, 0f, 5f,
                        0f, 0f, 1.3f, 0f, 30f,
                        0f, 0f, 0f, 1f, 0f
                    )),
                    ColorMatrix().apply { setSaturation(1.1f) }
                )
            }
            "moody", "drama" -> {
                // Low saturation, vignette, contrast boost
                cm.setConcat(
                    ColorMatrix(floatArrayOf(
                        1.1f, 0f, 0f, 0f, -10f,
                        0f, 1.1f, 0f, 0f, -10f,
                        0f, 0f, 1.1f, 0f, -10f,
                        0f, 0f, 0f, 1f, 0f
                    )),
                    ColorMatrix().apply { setSaturation(0.6f) }
                )
            }
            "vintage", "polaroid" -> {
                // Nostalgic pastel wash with matte highlights
                cm.setConcat(
                    ColorMatrix(floatArrayOf(
                        0.9f, 0.1f, 0.0f, 0.0f, 30f,
                        0.0f, 0.9f, 0.1f, 0.0f, 25f,
                        0.0f, 0.0f, 0.85f, 0.0f, 15f,
                        0.0f, 0.0f, 0.0f, 1.0f, 15f
                    )),
                    ColorMatrix().apply { setSaturation(0.85f) }
                )
            }
            "sunset", "breeze" -> {
                // Dreamy warm-magenta gradient wash
                cm.setConcat(
                    ColorMatrix(floatArrayOf(
                        1.15f, 0f, 0f, 0f, 20f,
                        0f, 0.95f, 0f, 0f, -5f,
                        0.1f, 0f, 1.1f, 0f, 15f,
                        0f, 0f, 0f, 1f, 0f
                    )),
                    ColorMatrix().apply { setSaturation(1.25f) }
                )
            }
            else -> {
                // Normal / identity
                cm.reset()
            }
        }

        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(base, 0f, 0f, paint)
        return output
    }

    /**
     * Crops, rotates, and flips the bitmap image safely.
     */
    fun transformBitmap(
        base: Bitmap,
        rotationDegrees: Float,
        cropRectPercent: RectF, // Rect dimensions in values between 0f and 1f
        flipHorizontal: Boolean,
        flipVertical: Boolean
    ): Bitmap {
        var matrix = Matrix()

        // Flip operations
        val scaleX = if (flipHorizontal) -1f else 1f
        val scaleY = if (flipVertical) -1f else 1f
        matrix.postScale(scaleX, scaleY, base.width / 2f, base.height / 2f)

        // Rotation
        if (rotationDegrees != 0f) {
            matrix.postRotate(rotationDegrees, base.width / 2f, base.height / 2f)
        }

        // Apply transformations first
        val transformed = Bitmap.createBitmap(base, 0, 0, base.width, base.height, matrix, true)

        // Crop operations
        val left = (cropRectPercent.left * transformed.width).toInt().coerceIn(0, transformed.width - 2)
        val top = (cropRectPercent.top * transformed.height).toInt().coerceIn(0, transformed.height - 2)
        val right = (cropRectPercent.right * transformed.width).toInt().coerceIn(left + 1, transformed.width)
        val bottom = (cropRectPercent.bottom * transformed.height).toInt().coerceIn(top + 1, transformed.height)

        val cropW = right - left
        val cropH = bottom - top

        return Bitmap.createBitmap(transformed, left, top, cropW, cropH)
    }

    /**
     * Simulates facial beauty adjustment filters using regional Canvas matrices.
     */
    fun applyBeauty(
        base: Bitmap,
        skinSmoothStrength: Float, // 0 to 100
        skinBrightenStrength: Float // 0 to 100
    ): Bitmap {
        val width = base.width
        val height = base.height
        val output = Bitmap.createBitmap(base)
        val canvas = Canvas(output)

        // Simulate beauty adjustments via soft filtering
        if (skinSmoothStrength > 0) {
            val blurPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                alpha = (skinSmoothStrength * 0.45f).toInt().coerceIn(0, 255)
            }
            // Generate a softly blurred copy and blend
            val blurRadius = (skinSmoothStrength / 100f) * 15f
            val blurred = blurBitmap(base, blurRadius.coerceAtLeast(1f))
            canvas.drawBitmap(blurred, 0f, 0f, blurPaint)
        }

        if (skinBrightenStrength > 0) {
            val brightenPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            val factor = skinBrightenStrength / 100f * 0.15f // max 15% bright overlay
            val cm = ColorMatrix(floatArrayOf(
                1f + factor, 0f, 0f, 0f, factor * 255f,
                0f, 1f + factor, 0f, 0f, factor * 255f,
                0f, 0f, 1f + factor, 0f, factor * 255f,
                0f, 0f, 0f, 1f, 0f
            ))
            brightenPaint.colorFilter = ColorMatrixColorFilter(cm)
            canvas.drawBitmap(output, 0f, 0f, brightenPaint)
        }

        return output
    }

    /**
     * Blur helper since RenderScript is deprecated and custom fast blur works perfect on any Android SDK version.
     */
    private fun blurBitmap(sentBitmap: Bitmap, radius: Float): Bitmap {
        val bitmap = Bitmap.createScaledBitmap(sentBitmap, (sentBitmap.width * 0.5f).toInt(), (sentBitmap.height * 0.5f).toInt(), false)
        val w = bitmap.width
        val h = bitmap.height
        val pix = IntArray(w * h)
        bitmap.getPixels(pix, 0, w, 0, 0, w, h)

        val r = radius.toInt()
        val wm = w - 1
        val hm = h - 1
        val wh = w * h
        val div = r + r + 1

        val rSum = IntArray(wh)
        val gSum = IntArray(wh)
        val bSum = IntArray(wh)
        var vIndex = 0

        val dv = IntArray(256 * div)
        for (i in 0 until 256 * div) {
            dv[i] = i / div
        }

        var rSum1: Int
        var gSum1: Int
        var bSum1: Int
        var p: Int
        var yi = 0

        for (y in 0 until h) {
            rSum1 = 0
            gSum1 = 0
            bSum1 = 0
            for (i in -r..r) {
                p = pix[yi + min(wm, max(i, 0))]
                rSum1 += p shr 16 and 0xff
                gSum1 += p shr 8 and 0xff
                bSum1 += p and 0xff
            }
            for (x in 0 until w) {
                rSum[vIndex] = rSum1
                gSum[vIndex] = gSum1
                bSum[vIndex] = bSum1

                if (y == 0) {
                    val p1 = pix[min(x + r + 1, wm)]
                    val p2 = pix[max(0, x - r)]
                    rSum1 += (p1 shr 16 and 0xff) - (p2 shr 16 and 0xff)
                    gSum1 += (p1 shr 8 and 0xff) - (p2 shr 8 and 0xff)
                    bSum1 += (p1 and 0xff) - (p2 and 0xff)
                }
                vIndex++
            }
            yi += w
        }

        for (x in 0 until w) {
            rSum1 = 0
            gSum1 = 0
            bSum1 = 0
            for (i in -r..r) {
                p = x + min(hm, max(i, 0)) * w
                rSum1 += rSum[p]
                gSum1 += gSum[p]
                bSum1 += bSum[p]
            }
            for (y in 0 until h) {
                pix[x + y * w] = (0xff000000.toInt() or (rSum1 / div shl 16) or (gSum1 / div shl 8) or (bSum1 / div))
                val p1 = x + min(y + r + 1, hm) * w
                val p2 = x + max(0, y - r) * w
                rSum1 += rSum[p1] - rSum[p2]
                gSum1 += gSum[p1] - gSum[p2]
                bSum1 += bSum[p1] - bSum[p2]
            }
        }

        val output = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        output.setPixels(pix, 0, w, 0, 0, w, h)
        return Bitmap.createScaledBitmap(output, sentBitmap.width, sentBitmap.height, true)
    }

    /**
     * Implements a full hardware-accelerated warp Mesh distortion engine!
     * Deforms a dense 2D mesh coordinate mapping around a localized pinch/drag gesture.
     */
    fun applyLiquifyWarp(
        base: Bitmap,
        meshPoints: FloatArray, // array of pairs [x, y] of size (meshWidth + 1) * (meshHeight + 1) * 2
        meshWidth: Int,
        meshHeight: Int
    ): Bitmap {
        val output = Bitmap.createBitmap(base.width, base.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        // Native Android fast drawing using displacement mesh matrix!
        canvas.drawBitmapMesh(
            base,
            meshWidth,
            meshHeight,
            meshPoints,
            0,
            null,
            0,
            paint
        )
        return output
    }

    /**
     * Generates an initial mesh grid of points based on dimensions.
     */
    fun createInitialMesh(width: Float, height: Float, meshWidth: Int, meshHeight: Int): FloatArray {
        val totalPoints = (meshWidth + 1) * (meshHeight + 1)
        val mesh = FloatArray(totalPoints * 2)
        var index = 0
        for (y in 0..meshHeight) {
            val fy = height * y / meshHeight
            for (x in 0..meshWidth) {
                val fx = width * x / meshWidth
                mesh[index++] = fx
                mesh[index++] = fy
            }
        }
        return mesh
    }

    /**
     * Warps a mesh in a certain direction centered around (touchX, touchY).
     */
    fun warpMesh(
        mesh: FloatArray,
        touchX: Float,
        touchY: Float,
        dragX: Float,
        dragY: Float,
        radius: Float,
        strength: Float, // 0f to 1f
        warpType: String // "push", "expand" (bloat), "contract" (pinch), "twirl"
    ): FloatArray {
        val updated = mesh.clone()
        val r2 = radius * radius
        for (i in 0 until mesh.size step 2) {
            val px = mesh[i]
            val py = mesh[i + 1]

            val dx = px - touchX
            val dy = py - touchY
            val dist2 = dx * dx + dy * dy

            if (dist2 < r2) {
                val dist = sqrt(dist2.toDouble()).toFloat()
                // Radial falloff: maximum displacement at touch center, fading to zero at circle boundary
                val ratio = (1f - dist / radius).pow(2)

                when (warpType.lowercase()) {
                    "push" -> {
                        updated[i] += dragX * ratio * strength
                        updated[i + 1] += dragY * ratio * strength
                    }
                    "expand" -> { // Bloat
                        if (dist > 0.01f) {
                            val pushAmt = 20f * ratio * strength
                            updated[i] += (dx / dist) * pushAmt
                            updated[i + 1] += (dy / dist) * pushAmt
                        }
                    }
                    "contract" -> { // Pinch
                        if (dist > 0.01f) {
                            val pullAmt = -15f * ratio * strength
                            updated[i] += (dx / dist) * pullAmt
                            updated[i + 1] += (dy / dist) * pullAmt
                        }
                    }
                    "twirl" -> { // Rotate
                        val angle = 0.5f * ratio * strength
                        val cosA = cos(angle.toDouble()).toFloat()
                        val sinA = sin(angle.toDouble()).toFloat()
                        updated[i] = touchX + dx * cosA - dy * sinA
                        updated[i + 1] = touchY + dx * sinA + dy * cosA
                    }
                }
            }
        }
        return updated
    }
}
