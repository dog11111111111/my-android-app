package com.example.data.models

import android.graphics.Bitmap
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import java.util.UUID

enum class LayerType {
    BASE_IMAGE,
    DRAWING,
    TEXT,
    STICKER
}

enum class BlendMode {
    NORMAL,
    MULTIPLY,
    SCREEN,
    OVERLAY
}

data class Layer(
    val id: UUID = UUID.randomUUID(),
    val name: String,
    val type: LayerType,
    val isVisible: Boolean = true,
    val opacity: Float = 1.0f,
    val blendMode: BlendMode = BlendMode.NORMAL,
    val zIndex: Int = 0
)

data class BrushSettings(
    val brushType: String = "Basic Round", // Basic Round, Soft Round, Airbrush, Marker, Pen
    val size: Float = 24f,                 // 5px to 200px
    val opacity: Float = 1.0f,              // 0% to 100%
    val hardness: Float = 0.8f,             // 0f to 1f (feathering)
    val color: Color = Color(0xFF7B2FFF),   // Electric Purple default
    val isEraser: Boolean = false
)

data class DrawingStroke(
    val id: UUID = UUID.randomUUID(),
    val points: List<Offset> = emptyList(),
    val settings: BrushSettings
)

data class TextOverlay(
    val id: UUID = UUID.randomUUID(),
    val text: String,
    val position: Offset = Offset(200f, 300f),
    val size: Float = 36f, // sp or pixel scaling
    val color: Color = Color.White,
    val fontName: String = "Syne", // Font categories
    val isBold: Boolean = false,
    val isItalic: Boolean = false,
    val scale: Float = 1.0f,
    val rotation: Float = 0f,
    // Style attributes
    val hasShadow: Boolean = false,
    val hasOutline: Boolean = false,
    val shadowColor: Color = Color.Black,
    val outlineColor: Color = Color.Magenta,
    val isGradient: Boolean = false,
    val gradientColors: List<Color> = listOf(Color(0xFF7B2FFF), Color(0xFFFF2D78))
)

data class StickerOverlay(
    val id: UUID = UUID.randomUUID(),
    val stickerName: String, // String ID of the emoji or PNG in assets
    val position: Offset = Offset(150f, 150f),
    val scale: Float = 1.0f,
    val rotation: Float = 0f
)

data class FilterItem(
    val name: String,
    val category: String,
    val id: String
)
