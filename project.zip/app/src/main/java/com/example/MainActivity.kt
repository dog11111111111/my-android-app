package com.example

import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.editor.EditorScreen
import com.example.ui.editor.EditorViewModel
import com.example.ui.gallery.GalleryScreen
import com.example.ui.home.HomeScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.export.ExportScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                var currentScreen by remember { mutableStateOf("home") }
                val editorViewModel: EditorViewModel = viewModel()
                var exportedBitmap by remember { mutableStateOf<Bitmap?>(null) }

                // Native Back button hardware gesture overriding
                BackHandler(enabled = currentScreen != "home") {
                    currentScreen = when (currentScreen) {
                        "gallery" -> "home"
                        "editor" -> "gallery"
                        "export" -> "editor"
                        else -> "home"
                    }
                }

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentScreen) {
                            "home" -> {
                                HomeScreen(
                                    onStartEditing = {
                                        currentScreen = "gallery"
                                    },
                                    onSelectQuickTool = { toolAction ->
                                        currentScreen = "gallery"
                                    }
                                )
                            }
                            "gallery" -> {
                                GalleryScreen(
                                    onNavigateBack = {
                                        currentScreen = "home"
                                    },
                                    onPhotoSelected = { bitmap ->
                                        editorViewModel.initializeWithBitmap(bitmap)
                                        currentScreen = "editor"
                                    }
                                )
                            }
                            "editor" -> {
                                EditorScreen(
                                    viewModel = editorViewModel,
                                    onNavigateBack = {
                                        currentScreen = "gallery"
                                    },
                                    onNavigateToExport = { finalBitmap ->
                                        exportedBitmap = finalBitmap
                                        currentScreen = "export"
                                    }
                                )
                            }
                            "export" -> {
                                val bitmap = exportedBitmap
                                if (bitmap != null) {
                                    ExportScreen(
                                        bitmap = bitmap,
                                        onNavigateBack = {
                                            currentScreen = "editor"
                                        },
                                        onNavigateHome = {
                                            currentScreen = "home"
                                        }
                                    )
                                } else {
                                    currentScreen = "editor"
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
